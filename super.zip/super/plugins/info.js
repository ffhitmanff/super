let handler  = async (m, { conn, usedPrefix: _p }) => {
  conn.reply(m.chat, `
╠═〘 INFO BOT 〙 ═
╠➥ Dibuat dengan bahasa javascript via NodeJs
╠➥ Rec: HITMAN
╠➥ Script: @HITMAN
║
╠➥ Github: github.com/ffhitmanff/
╠➥ Instagram: @ff.hitmanff
╠➥ YouTube: HITMAN FF
║
╠═〘 Thanks To 〙 ═
╠➥ HITMAN
╠➥ MIKASA
╠➥ HITMAN-BOT
╠➥ Dan kawan yang lain :)
║
╠═〘 DONASI 〙 ═
╠➥ SmartFren: COMINGSOON!
╠➥ Tsel: 0821-5548-3269
╠➥ Indosat: COMINGSOON!
║
║>Request? Wa.me/6282156986313
║
╠═〘 HITMAN BOT 〙 ═
`.trim(), m)
}
handler.help = ['info']
handler.tags = ['about']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

